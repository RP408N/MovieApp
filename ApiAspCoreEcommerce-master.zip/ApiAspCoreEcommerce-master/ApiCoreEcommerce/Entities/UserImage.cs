namespace ApiCoreEcommerce.Entities
{
    public class UserImage
    {
        
        public ApplicationUser User { get; set; }
        public long UserId;
    }
}