using System;

namespace BlogDotNet.Models.ViewModels.User
{
    public class UserSummaryViewModel
    {
        public string UserName { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}