namespace ApiCoreEcommerce.Enums
{
    public enum ShippingStatus
    {
        Ordered, Processed, Shipped
    }
}