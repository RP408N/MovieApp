namespace ApiCoreEcommerce.Enums
{
    public enum AuthorizationPolicy
    {
        ONLY_ADMIN, ADMIN_AND_OWNER, ONLY_OWNER, AUTHENTICATED_USER, ANY
    }
}